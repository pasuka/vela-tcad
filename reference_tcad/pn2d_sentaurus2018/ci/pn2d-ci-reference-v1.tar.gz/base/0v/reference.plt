DF-ISE text

Info {
  version   = 1.0
  type      = xyplot
  datasets  = [
    "time"
    "Cathode OuterVoltage" "Cathode InnerVoltage" "Cathode QuasiFermiPotential" "Cathode DisplacementCurrent" "Cathode eCurrent"
    "Cathode hCurrent" "Cathode TotalCurrent" "Cathode Charge" "Anode OuterVoltage" "Anode InnerVoltage"
    "Anode QuasiFermiPotential" "Anode DisplacementCurrent" "Anode eCurrent" "Anode hCurrent" "Anode TotalCurrent"
    "Anode Charge" ]
  functions = [
    Time
    OuterVoltage InnerVoltage QuasiFermiPotential DisplacementCurrent eCurrent
    hCurrent TotalCurrent Charge OuterVoltage InnerVoltage
    QuasiFermiPotential DisplacementCurrent eCurrent hCurrent TotalCurrent
    Charge ]
}

Data {
      0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00  -4.97199515103199E-26
      4.87387433891278E-25   4.37667482380958E-25   5.28941943767407E-16   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   4.97199428174124E-26  -4.87387425198370E-25  -4.37667482380957E-25
     -5.28941943767407E-16
      0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00   0.00000000000000E+00  -8.26456006272345E-26
      7.71427785714394E-25   6.88782185087160E-25   5.28941933930105E-16   0.00000000000000E+00   0.00000000000000E+00
      0.00000000000000E+00   0.00000000000000E+00   8.26455943395610E-26  -7.71427779426716E-25  -6.88782185087155E-25
     -5.28941933930103E-16
}
